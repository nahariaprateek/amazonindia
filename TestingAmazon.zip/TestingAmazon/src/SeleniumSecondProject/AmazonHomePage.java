package SeleniumSecondProject;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;


public class AmazonHomePage extends BaseClass {
	
	Actions action;
	 private By productSearchBar = By.id("twotabsearchtextbox");
	
	 //phone
	 private By product = By.xpath("/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[1]/div/div/span/a/div/img");
	 
	 //
	 private By featuredsort = By.id("a-autoid-0-announce");
	 private By lowtohighh = By.xpath("//*[@id=\"s-result-sort-select_1\"]");
	 private By Btnaddtocart = By.id("add-to-cart-button");
	 
	 
//-----------Functions/Methods Below---------------	
	 public void NavigateTo()  {
		
		driver.navigate().to("https://www.amazon.in/"); 
		
		Actions actions = new Actions(driver);
		Action action = actions.sendKeys(Keys.ESCAPE).build();
		action.perform();

	}
	
	

	public  void ClickProduct() {
		
		WebElement searchImage = driver.findElement(product);
		//main.performMouseOver(searchImage);
		searchImage.click();
		
		System.out.println("The Product is Searched and Selected Successfully " + searchImage);
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//-------------------------
	
	public WebElement searchTheProduct() {
		return getDriver().findElement(productSearchBar);
			
		
	}
	
	public void buttonaddtocard() {
	
		WebElement buttonaddcart = driver.findElement(Btnaddtocart);
		buttonaddcart.click();

		// Print the Exception ------
		
		
	}
	
	//---------------------------------
	public void featuredsorting() {
		driver.findElement(featuredsort).click();
		WebElement lowtohigh = driver.findElement(lowtohighh);
		lowtohigh.click();
		System.out.println("Sorting Product Done " +lowtohigh);
	}
		//driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).click();

	public void scrolldown()throws Exception {
	WebElement element = driver.findElement(By.id("id_of_element"));
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	Thread.sleep(500); 
	}
	
	
	public void LoginPage() {
		
		WebElement login = driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
		
		action.moveToElement(login).build().perform();
		
		
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).click();
		driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		
	
	System.out.println("Login Done Successfully" +login);
	
	}
	}


