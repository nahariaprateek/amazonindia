package SeleniumSecondProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel extends BaseClass {
	
	public void  readxlsx() throws Exception {
	
	File src = new File("//Users//prateeknaharia//Desktop//AmazonDataDriven.xlsx");
	
	FileInputStream fis = new FileInputStream(src);
	
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	
	XSSFSheet sheet1 = wb.getSheetAt(0);
	
	
	int rowcount=sheet1.getLastRowNum();
	System.out.println("Total No of Rows is :" +rowcount+1);
	
	for (int i=0;i<rowcount;i++)
	{
		
		String username = sheet1.getRow(i).getCell(0).getStringCellValue();
		System.out.println("The UserName:" +username);
	}
	  
	wb.close();
	 
	 
	}

}
