package SeleniumSecondProject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class TestMain {

	public static WebDriver driver;
	public static Actions action;

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException, Exception {

		// Objects of Every Class/ Page ( POM)

		AmazonHomePage homepage = new AmazonHomePage();

		ProductPage productpage = new ProductPage();

		homepage.initialize();
		homepage.NavigateTo();

		/*
		 * LOGIN PAGE DETAILS COMMENTED ************
		 * 
		 * WebElement btn = driver.findElement(By.xpath(
		 * "/html/body/div[1]/header/div/div[1]/div[2]/div/a[2]/span[1]"));
		 * action.moveToElement(btn).build().perform(); btn.click();
		 * 
		 * 
		 * 
		 * WebElement login = driver.findElement(By.id("a-autoid-0-announce"));
		 * action.moveToElement(login).build().perform(); login.click();
		 * 
		 * 
		 * 
		 * try { Thread.sleep(10000); } catch (InterruptedException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 * 
		 * WebElement username = driver.findElement(By.id("ap_email"));
		 * action.moveToElement(username).build().perform(); username.click();
		 * username.sendKeys("prateeknnaaharia@gmail.com");
		 * 
		 * driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		 * driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
		 * driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		 * 
		 * 
		 * System.out.println("Login Done Successfully" +login);
		 * 
		 */

		// homepage.LoginPage();

		System.out.println("SearchBoxClicked");
		homepage.searchTheProduct().sendKeys("phone");
		homepage.searchTheProduct().sendKeys(Keys.ENTER);
		performAction(homepage.getDriver());

		homepage.featuredsorting();

		
		/* In ORDER TO SCROLL DOWN THE WEBPAGE
		 * 
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("window.scrollBy(0,1000)");
		 */		
		
		/*
		 * // js.executeScript("javascript:window.scrollBy(250,350)");
		 * 
		 * WebElement element = driver.findElement(By.id("low-price"));
		 * ((JavascriptExecutor)
		 * driver).executeScript("arguments[0].scrollIntoView(true);", element);
		 * Thread.sleep(500);
		 */
		
		
		homepage.ClickProduct();
	
		By Btnaddtocart = By.id("add-to-cart-button");

		WebElement buttonaddcart = driver.findElement(Btnaddtocart);
		action.moveToElement(buttonaddcart).build().perform();
		buttonaddcart.click();

		homepage.buttonaddtocard();

		productpage.clickBuyNow();
		
		

		
		//-------LOGIN PAGE---------------------------
		AmazonLoginPage loginpage = new AmazonLoginPage();

		loginpage.navigateTo();
		loginpage.getUserName().sendKeys("prateeknnaaharia@gmail.com");
		loginpage.getcontinue().click();
		loginpage.getpassword().sendKeys("rj45cd4584prateek");
		loginpage.getloginbutton().click();

	}

	private static void performAction(WebDriver driver) {
		// TODO Auto-generated method stub

	}

}
