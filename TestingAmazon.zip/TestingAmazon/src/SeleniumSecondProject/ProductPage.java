package SeleniumSecondProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ProductPage extends BaseClass{

	WebDriver driver ;
	Actions action;
	
	private By buynow = By.xpath("/html/body/div[2]/div[2]/div[4]/div[6]/div[1]/div[3]/div/div/div/form/div/div/div/div/div[2]/div/div[32]/div/div/span/span/input");
	
	
	
	
	public void clickBuyNow() throws InterruptedException {
		
		WebElement clicknowbutton = driver.findElement(buynow);
		clicknowbutton.click();
		
		Thread.sleep(10000);    // OR you can add try catch block over the thread sleep 
		
	
	}
	
	
	
	
}
