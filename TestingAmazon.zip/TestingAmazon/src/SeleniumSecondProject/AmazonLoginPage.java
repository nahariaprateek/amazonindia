package SeleniumSecondProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class AmazonLoginPage extends BaseClass {
	
	private WebElement signinbutton = getDriver().findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[4]/div[8]/div[2]/a/span"));
	
	private WebElement emailid = getDriver().findElement(By.xpath("//*[@id=\"ap_email\"]"));
	
	private  WebElement continuebutton = getDriver().findElement(By.xpath("//*[@id=\"continue\"]"));
	
	private WebElement password = getDriver().findElement(By.xpath("//*[@id=\"ap_password\"]"));
	
	private WebElement loginbutton = getDriver().findElement(By.xpath("//*[@id=\"signInSubmit\"]"));
	
	
	
	public WebElement getUserName() {
		
		return emailid;
	}
	public WebElement getcontinue() {
		return continuebutton;
	}
	public WebElement getpassword() {
		return password;
	}
	public WebElement getloginbutton() {
		return loginbutton;
	}
	
	
	public void navigateTo() {
		
		signinbutton.click(); 
		/*
		 * emailid.click(); continuebutton.click(); password.click();
		 * loginbutton.click();
		 */	}

}
