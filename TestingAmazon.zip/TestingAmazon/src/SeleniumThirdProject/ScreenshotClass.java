package SeleniumThirdProject;

import java.io.File;

import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//import org.testng.annotations.Test;

public class ScreenshotClass {

    //Screenshot FrameWork 
	
	

    public void ScreenshotClass() throws Exception{

		WebDriver driver ;
		System.setProperty("webdriver.chrome.driver", "/Users/prateeknaharia/Downloads/Selenium/chromedriver");
    	driver = new ChromeDriver();

        //goto url

        driver.get("https://www.amazon.in/");

        //Call take screenshot function

        this.takeSnapShot(driver, "c://test.png") ;     

    }

    /**

     * This function will take screenshot

     * @param webdriver

     * @param fileWithPath

     * @throws Exception

     */

    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination

               // FileUtils.copyFile(SrcFile, DestFile);

    }

}