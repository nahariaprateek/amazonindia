package SeleniumFirstProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

//import com.sun.org.apache.bcel.internal.generic.Select;

public class AmazonMain {
	
	static Actions action;
	public WebDriver driver; 
	public static String baseurl = "https://www.amazon.in/";
	
	/**
	 * 
	 * @param driver, basic methods which we are going to perform for the automations
	 */
	
	public AmazonMain(WebDriver driver) {
		action = new Actions(driver);
		
	}
	
	
	public void pressEnter() {
		
		action.sendKeys(Keys.ENTER).build().perform();
		
	}
	
	// Scroll method - which can have seperate class in order to have 4 more methods for scrolling
	public void scrollDown(WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("window.scrollBy(0,1000)", "");
		//executor.executeScript("arguments[0].scrollIntoView();", Element);
	}
	
	public void performMouseOver(WebElement element) {
		action.moveToElement(element).build().perform();
	}
	
	
	public void clickUsingJavascriptExecutor(WebElement element, WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);	
		
	}
	//-----------------------LOGIN PAGE---------------------------------//
	/*
	 * public void loginPage(WebElement element,WebDriver driver) { WebElement login
	 * = driver.findElement(By.xpath(
	 * "/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
	 * action.moveToElement(login).build().perform();
	 * 
	 * try { Thread.sleep(10000); } catch (InterruptedException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * driver.findElement(By.xpath(
	 * "/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).
	 * click();
	 * driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
	 * driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
	 * driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
	 * driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
	 * 
	 * }
	 */
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/Users/prateeknaharia/Downloads/Selenium/chromedriver");
		WebDriver driver = new ChromeDriver();
	
		/* In order to deal with multiple browser----
		 * public void setup(String Browser)
		 * if(browser.equals("chrome")){
		 * System.setProperty(:"x","x");
		 * driver = new ChromeDriver();}
		 * 
		 * 
		 * elseif(browser.equals("firefox")
		 * { 	System.setProperty();
		 * driver=new FireFoxDriver("x","x");}
		 * */
		// ----------------------------------------------
		
		AmazonMain main = new AmazonMain(driver);     // Object for the Class AmazonMain	
		
	
		driver.get(baseurl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		System.out.println("The Website :" + baseurl);
	
		//-----------------------LOGIN PAGE---------------------------------	
		//public void loginPage(WebElement element,WebDriver driver) 
		
		WebElement btnlogin = driver.findElement(By.id("a-autoid-0-announce"));
		action.moveToElement(btnlogin).build().perform();
		btnlogin.click();
		
	
		
		/*  ANOTHER ELEMENT ON THE TOOL BAR-----HOVER THE MOUSE AND THEN CLICK 
		 * 
		 * WebElement login = driver.findElement(By.xpath(
		 * "/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
		 * action.moveToElement(login).build().perform();
		 */	
			
		
		
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			WebElement username = driver.findElement(By.id("ap_email"));
			action.moveToElement(username).build().perform();
			username.click();
			username.sendKeys("prateeknnaaharia@gmail.com");
			
			
			
		//	driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).click();
			//driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
			driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
			driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
			driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
			
			
			
		
		System.out.println("Login Done Successfully" +btnlogin);
		
		//--------------------------------------------------------------------
		
			
	
		driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("Phone");
	//	WebElement inputsearch = driver.findElement(By.id("twotabsearchtextbox"));
		main.pressEnter();
		
		
	//Featured sorting
		
		driver.findElement(By.id("a-autoid-0-announce")).click();
		WebElement lowtohigh = driver.findElement(By.xpath("//*[@id=\"s-result-sort-select_1\"]"));
		lowtohigh.click();
		System.out.println("Sorting Product Done " +lowtohigh);
		//	main.scrollDown(driver);
		
		/**
		 * This Will Select the desired selected item from the list of products as the image = n values can be changed upon scrolling
		 * */
		//String image = "2";
		WebElement searchImage = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div[2]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[1]/div/div/span/a/div/img"));
		main.performMouseOver(searchImage);
		searchImage.click();
	
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		// Quantity option on the webpage
		
		WebElement quantity = driver.findElement(By.xpath("//*[@id=\"quantity\"]"));
		main.clickUsingJavascriptExecutor(quantity, driver);
		//Select select = new Select(driver.findElement(By.id("")));
		
		System.out.println("The Quantity is 1" +quantity);
		
		
		
		//cart.clickAddToCart();
		
		WebElement cartButton = driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]"));
		main.clickUsingJavascriptExecutor(cartButton, driver);
		System.out.println("The Add Cart Button has been pressed successfully" +cartButton);
		
		
		//main.performMouseOver(cartButton);
		//cartButton.click();
		
		
		
		
		
		

	}

}
