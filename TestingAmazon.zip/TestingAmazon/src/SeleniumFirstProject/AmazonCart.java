package SeleniumFirstProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AmazonCart {


	static Actions action;
	public WebDriver driver; 
	public static String baseurl = "https://www.amazon.in/";
	
	
	public AmazonCart(WebDriver driver) {
		action = new Actions(driver);
		
	}
	
	
	public void pressEnter() {
		
		action.sendKeys(Keys.ENTER).build().perform();
		
	}
	
	// Scroll method - which can have seperate class in order to have 4 more methods for scrolling
	public void scrollDown(WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("window.scrollBy(0,1000)", "");
		//executor.executeScript("arguments[0].scrollIntoView();", Element);
	}
	
	public void performMouseOver(WebElement element) {
		action.moveToElement(element).build().perform();
	}
	
	
	public void clickUsingJavascriptExecutor(WebElement element, WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);	
		
	}
	//-----------------------LOGIN PAGE---------------------------------//
	public void loginPage(WebElement element,WebDriver driver) {
		WebElement login = driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
		action.moveToElement(login).build().perform();
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).click();
		driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		
	}
	

	
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "/Users/prateeknaharia/Downloads/Selenium/chromedriver");
		WebDriver driver = new ChromeDriver();
	
		AmazonCart cart = new AmazonCart(driver);
		driver.get(baseurl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		System.out.println("The Website :" + baseurl);
		
		  WebElement login = driver.findElement(By.xpath(
		  "/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
		  action.moveToElement(login).build().perform();
		 
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).click();
		driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		
	
	System.out.println("Login Done Successfully" +login);
	

	
	WebElement helloUser = driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/div/div[1]/div[2]/div/a[2]/span[1]"));
	action.moveToElement(helloUser).build().perform();

	
	WebElement carticon = driver.findElement(By.xpath("/html/body/div[1]/header/div/div[5]/div[2]/div/div/a[9]"));
	action.moveToElement(carticon).build().perform();
	carticon.click();
	 
	driver.findElement(By.xpath("/html/body/div[1]/div[4]/div/div[5]/div/div[1]/div[3]/form/div/div/div/span/span/input")).click();
	
	
		

	}

}
