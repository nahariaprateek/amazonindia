package SeleniumFirstProject;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * @author prateeknaharia
 *
 */
public class loginAmazon {

	public static WebDriver driver;
	Actions act;
	// private static WebDriver driver2;

	/**
	 * LaunchBrowser function has been created, for lauching the chrome browser
	 * Launching the Website - Amazon.in
	 * Also Maximizing the window.
	 * */
	
	
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "/Users/prateeknaharia/Downloads/Selenium/chromedriver");
		driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		
	}
	
	
	/**
	 Scroll Function 
	*/		
	
	public void scrollDown( WebDriver driver) {
		JavascriptExecutor executor =(JavascriptExecutor) driver;
		executor.executeScript("window.scrollBy(0,2000)", "");
	} 
		
	
	public static void main(String[] args) {
		
		
		loginAmazon obj = new loginAmazon();
				obj.launchBrowser();
				/**
				 * Creating Action function in order to hover mouse to a webelement
				 **/
				WebElement login = driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
				
				Actions act = new Actions(driver);
				
				act.moveToElement(login).build().perform();
				
				/*
				 *  We need to wait for 1 sec just after the mouse hover 
				 * */
				
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		/* 
		 * We need to get the signin/login button 
		 * */
				driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/div[2]/div[2]/div/div[1]/div/a/span")).click();

			//	driver.findElement(By.id("a-autoid-0-announce")).click();   //- This in order to directly click the signin.
				
				driver.findElement(By.id("ap_email")).sendKeys("prateeknnaaharia@gmail.com");
				
				driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
				
				driver.findElement(By.id("ap_password")).sendKeys("rj45cd4584prateek");
				
				driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
				
	/**
	 * Signin Approved
	 * */
				
				
			/**
			 * Search A Product Table and select the first product
			 * */
				
				WebElement searchbar = driver.findElement(By.id("twotabsearchtextbox"));
				searchbar.sendKeys("Keys");
				searchbar.sendKeys(Keys.ENTER);
			
				
/**
 * Sort By Featured 
  **/				
				driver.findElement(By.id("a-autoid-0-announce")).click();
				WebElement lowtohigh = driver.findElement(By.xpath("//*[@id=\"s-result-sort-select_1\"]"));
				lowtohigh.click();
				
	/* 
	 * Scroll Down a page upto its visibility/ elements visibility
	 * And Click the Particular Product 
	 * */
				
				driver.findElement(By.xpath("//span[text()='Online Store only Sucker Stand for Cell Phone Metal Mobile Holder 360°Rotatable Flower Type Mobile Stand for Best Used to Office Work.']")).click();
		
				WebElement phone = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div[1]/div/div/div/h2/a/span"));	
				 JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,1000)");
				 js.executeScript("arguments[0].scrollIntoView();", phone);
				 
		
		
				
				/**
		 * Buying the product  - Buy Now 
		 */
		
	driver.findElement(By.id("buy-now-button")).click();
	
		driver.close();
				
	}

}
