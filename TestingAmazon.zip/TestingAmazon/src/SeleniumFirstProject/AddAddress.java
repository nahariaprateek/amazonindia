package SeleniumFirstProject;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AddAddress{

	public static WebDriver driver;
	public static Actions action;
	
	public static String baseurl = "https://www.amazon.in/";
	
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "/Users/prateeknaharia/Downloads/Selenium/chromedriver");
		driver = new ChromeDriver();
		driver.get(baseurl);
		driver.manage().window().maximize();
		
		
	}
	
	public void scrollDown(WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("window.scrollBy(0,1000)", "");
		//executor.executeScript("arguments[0].scrollIntoView();", Element);
	}
	
	
	public void performMouseOver(WebElement element) {
		action.moveToElement(element).build().perform();
	}
	
	
	public void clickUsingJavascriptExecutor(WebElement element, WebDriver driver) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);	
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AddAddress address = new AddAddress();
		address.launchBrowser();
		
		driver.findElement(By.id("a-autoid-0-announce")).click();
		
		String expectedtitle = "Amazon Sign In";
		String actualtitle = driver.getTitle();
		
		
		if(expectedtitle.equals(actualtitle)) {
			System.out.println("Login Successfull");
		}
		else {
			System.out.println("Login Failed");
		}
		
		
	
		
		
		/*
		 * WebElement accountandlist = driver.findElement(By.xpath(
		 * "/html/body/div[1]/header/div/div[1]/div[3]/div/a[2]/span[1]"));
		 * action.moveToElement(accountandlist).perform();
		 * 
		 * 
		 * address.performMouseOver(accountandlist); accountandlist.click();
		 * address.clickUsingJavascriptExecutor(accountandlist, driver);
		 */	
		
		
		
	}

}
