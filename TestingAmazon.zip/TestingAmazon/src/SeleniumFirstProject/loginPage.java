package SeleniumFirstProject;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginPage extends AmazonMain {


	public loginPage(WebDriver driver) {
		super(driver);
		
		driver.get(baseurl);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		
		driver.findElement(By.id("a-autoid-0-announce")).click();
	
		
		
		// TODO Auto-generated constructor stub
	}



	


	

}
